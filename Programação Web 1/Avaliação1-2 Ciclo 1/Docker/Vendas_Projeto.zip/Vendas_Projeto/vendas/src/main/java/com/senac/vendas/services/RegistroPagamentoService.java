package com.senac.vendas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.vendas.entities.RegistroPagamento;
import com.senac.vendas.repository.RegistroPagamentoRepository;

@Service
public class RegistroPagamentoService {
	private RegistroPagamentoRepository registroPagamentoRepository;
	
	public RegistroPagamentoService(RegistroPagamentoRepository registroPagamentoRepository) {
		this.registroPagamentoRepository = registroPagamentoRepository;
	}
	
	public List<RegistroPagamento> listarRegistroPagamento() {
		return this.registroPagamentoRepository.findAll();
	}
	
	public RegistroPagamento salvarRegistroPagamento(RegistroPagamento registroPagamento) {
		return this.registroPagamentoRepository.save(registroPagamento);
	}
}	