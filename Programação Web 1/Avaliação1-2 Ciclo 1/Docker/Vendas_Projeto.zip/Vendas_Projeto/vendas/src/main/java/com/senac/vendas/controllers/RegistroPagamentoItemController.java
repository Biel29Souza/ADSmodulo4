package com.senac.vendas.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.vendas.entities.RegistroPagamentoItem;
import com.senac.vendas.services.RegistroPagamentoItemService;

@RestController
@RequestMapping(value = "/registro_pagamento_item")
public class RegistroPagamentoItemController {

	private RegistroPagamentoItemService registroPagamentoItemService;

	public RegistroPagamentoItemController(RegistroPagamentoItemService registroPagamentoItemService) {
		this.registroPagamentoItemService = registroPagamentoItemService;
	}
	
	@GetMapping("/list")	
	public ResponseEntity<List<RegistroPagamentoItem>> listarRegistroPagamentoItem(){
		List<RegistroPagamentoItem> registropagamentoitem = this.registroPagamentoItemService.listarRegistroPagamentoItem();
		return ResponseEntity.ok(registropagamentoitem);
	}
}
