package com.senac.vendas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.vendas.entities.RegistroPagamentoItem;
import com.senac.vendas.repository.RegistroPagamentoItemRepository;


@Service
public class RegistroPagamentoItemService {

	private RegistroPagamentoItemRepository registroPagamentoItemRepository;
	
	public RegistroPagamentoItemService(RegistroPagamentoItemRepository registroPagamentoItemRepository) {
		this.registroPagamentoItemRepository = registroPagamentoItemRepository;
	}
	
	public List<RegistroPagamentoItem> listarRegistroPagamentoItem() {
		return this.registroPagamentoItemRepository.findAll();
	}
	
	public RegistroPagamentoItem salvarRegistroPagamentoItem(RegistroPagamentoItem registroPagamentoItem) {
		return this.registroPagamentoItemRepository.save(registroPagamentoItem);
	}
}
