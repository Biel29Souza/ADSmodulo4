package com.senac.vendas.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="entrega_endereco")
public class EntregaEndereco {

	@Id
	@Column(name="entrega_endereco_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
		
	@Column(name="entrega_endereco_endereco")
	private String endereco_endereco; 
	
	@Column(name="entrega_endereco_cep")
	private String endereco_cep; 
	
	//Relacao com a tabela Registro Pagamento
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="registro_pagamento_id")
	private RegistroPagamento registroPagamento;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEndereco_endereco() {
		return endereco_endereco;
	}

	public void setEndereco_endereco(String endereco_endereco) {
		this.endereco_endereco = endereco_endereco;
	}

	public String getEndereco_cep() {
		return endereco_cep;
	}

	public void setEndereco_cep(String endereco_cep) {
		this.endereco_cep = endereco_cep;
	}

	public RegistroPagamento getRegistropagamento() {
		return registroPagamento;
	}

	public void setRegistropagamento(RegistroPagamento registropagamento) {
		this.registroPagamento = registropagamento;
	}

	
	
	
	
}
