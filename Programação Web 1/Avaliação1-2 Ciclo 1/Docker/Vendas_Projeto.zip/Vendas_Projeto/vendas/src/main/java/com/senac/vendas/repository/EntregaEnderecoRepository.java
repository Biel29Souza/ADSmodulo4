package com.senac.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senac.vendas.entities.EntregaEndereco;


public interface EntregaEnderecoRepository extends JpaRepository <EntregaEndereco, Integer>{

}
