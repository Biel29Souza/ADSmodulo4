package com.senac.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.senac.vendas.entities.RegistroPagamento;

@Repository
public interface RegistroPagamentoRepository extends JpaRepository <RegistroPagamento, Integer> {

}

