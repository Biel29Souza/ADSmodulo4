package com.senac.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senac.vendas.entities.RegistroPagamentoItem;

public interface RegistroPagamentoItemRepository extends JpaRepository <RegistroPagamentoItem, Integer> {

}
