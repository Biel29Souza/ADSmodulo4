package com.senac.vendas.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.vendas.entities.RegistroPagamento;
import com.senac.vendas.services.RegistroPagamentoService;

@RestController
@RequestMapping(value = "/registro_pagamento")

public class RegistroPagamentoController {

	private RegistroPagamentoService registroPagamentoService;

	public RegistroPagamentoController(RegistroPagamentoService registroPagamentoService) {
		this.registroPagamentoService = registroPagamentoService;
	}
	
	@GetMapping("/list")	
	public ResponseEntity<List<RegistroPagamento>> listarRegistroPagamento(){
		List<RegistroPagamento> registropagamento = this.registroPagamentoService.listarRegistroPagamento();
		return ResponseEntity.ok(registropagamento);
	}
	
	
}



	