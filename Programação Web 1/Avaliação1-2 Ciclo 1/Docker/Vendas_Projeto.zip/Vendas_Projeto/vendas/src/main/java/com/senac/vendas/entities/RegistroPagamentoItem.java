package com.senac.vendas.entities;

import java.text.DecimalFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name="registro_pagamento_item")
public class RegistroPagamentoItem {

	@Id
	@Column(name="registro_pagamento_item_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="estoque_id")
	private int estoque; 
	
	@Column(name="registro_pagamento_item_quantidade")
	private int item_quantidade; 
	
	@Column(name="registro_pagamento_item_preco_unitario")
	private DecimalFormat item_preco_unitario; 
	
	@Column(name="registro_pagamento_item_sub_total")
	private DecimalFormat item_sub_total;
	
	
	//Relacao com a tabela Registro Pagamento
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="registro_pagamento_id", nullable=false)
	private RegistroPagamento registro_pagamento;
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEstoque() {
		return estoque;
	}

	public void setEstoque(int estoque) {
		this.estoque = estoque;
	}

	public int getItem_quantidade() {
		return item_quantidade;
	}

	public void setItem_quantidade(int item_quantidade) {
		this.item_quantidade = item_quantidade;
	}

	public DecimalFormat getItem_preco_unitario() {
		return item_preco_unitario;
	}

	public void setItem_preco_unitario(DecimalFormat item_preco_unitario) {
		this.item_preco_unitario = item_preco_unitario;
	}

	public DecimalFormat getItem_sub_total() {
		return item_sub_total;
	}

	public void setItem_sub_total(DecimalFormat item_sub_total) {
		this.item_sub_total = item_sub_total;
	}

	public RegistroPagamento getRegistro_pagamento() {
		return registro_pagamento;
	}

	public void setRegistro_pagamento(RegistroPagamento registro_pagamento) {
		this.registro_pagamento = registro_pagamento;
	} 
	
	
	
	
	
	
}
