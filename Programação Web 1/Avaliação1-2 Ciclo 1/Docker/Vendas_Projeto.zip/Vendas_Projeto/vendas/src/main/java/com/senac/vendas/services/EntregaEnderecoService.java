package com.senac.vendas.services;

import java.util.List;

import org.springframework.stereotype.Service;
import com.senac.vendas.entities.EntregaEndereco;
import com.senac.vendas.repository.EntregaEnderecoRepository;


@Service
public class EntregaEnderecoService {

private EntregaEnderecoRepository entregaEnderecoRepository;
	
	public EntregaEnderecoService(EntregaEnderecoRepository entregaEnderecoRepository) {
		this.entregaEnderecoRepository = entregaEnderecoRepository;
	}
	
	public List<EntregaEndereco> listarEntregaEndereco() {
		return this.entregaEnderecoRepository.findAll();
	}
	
	public EntregaEndereco salvarEntregaEndereco(EntregaEndereco entregaEndereco) {
		return this.entregaEnderecoRepository.save(entregaEndereco);
	}
}
