package com.senac.vendas.entities;

import java.time.LocalDate;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="registro_pagamento")
public class RegistroPagamento {

	@Id
	@Column(name="registro_pagamento_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="registro_pagamento_numero")
	private int pagamento_numero; 
	
	
	@Column(name="registro_pagamento_data")
	private LocalDate pagamento_data;
	
	@Column(name="registro_pagamento_chave_nfe")
	private String pagamento_chave_nfe;
	
	@Column(name="registro_pagamento_valor_total")
	private Float pagamento_valor_total;
	
	@Column(name="registro_pagamento_status")
	private int pagamento_status;
	
	
	//Relacao com a tabela Entrega Endereco
	@OneToOne(mappedBy="registroPagamento")
	@JsonIgnore
	private EntregaEndereco entregaEndereco;
	
	@OneToMany(mappedBy = "registro_pagamento")
	private Set<RegistroPagamentoItem> registropagamentoitem;
	

	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPagamento_numero() {
		return pagamento_numero;
	}

	public void setPagamento_numero(int pagamento_numero) {
		this.pagamento_numero = pagamento_numero;
	}

	public LocalDate getPagamento_data() {
		return pagamento_data;
	}

	public void setPagamento_data(LocalDate pagamento_data) {
		this.pagamento_data = pagamento_data;
	}

	public String getPagamento_chave_nfe() {
		return pagamento_chave_nfe;
	}

	public void setPagamento_chave_nfe(String pagamento_chave_nfe) {
		this.pagamento_chave_nfe = pagamento_chave_nfe;
	}

	public Float getPagamento_valor_total() {
		return pagamento_valor_total;
	}

	public void setPagamento_valor_total(Float pagamento_valor_total) {
		this.pagamento_valor_total = pagamento_valor_total;
	}

	public int getPagamento_status() {
		return pagamento_status;
	}

	public void setPagamento_status(int pagamento_status) {
		this.pagamento_status = pagamento_status;
	}

	public EntregaEndereco getEntregaEndereco() {
		return entregaEndereco;
	}

	public void setEntregaEndereco(EntregaEndereco entregaEndereco) {
		this.entregaEndereco = entregaEndereco;
	}

	public Set<RegistroPagamentoItem> getRegistropagamentoitem() {
		return registropagamentoitem;
	}

	public void setRegistropagamentoitem(Set<RegistroPagamentoItem> registropagamentoitem) {
		this.registropagamentoitem = registropagamentoitem;
	}
	
	
}
