package com.senac.vendas.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.vendas.entities.EntregaEndereco;
import com.senac.vendas.services.EntregaEnderecoService;


@RestController
@RequestMapping(value = "/entrega_endereco")
public class EntregaEnderecoController {

	private EntregaEnderecoService entregaEnderecoService;

	public EntregaEnderecoController(EntregaEnderecoService entregaEnderecoService) {
		this.entregaEnderecoService = entregaEnderecoService;
	}
	
	@GetMapping("/list")	
	public ResponseEntity<List<EntregaEndereco>> listarEntregaEndereco(){
		List<EntregaEndereco> entregaendereco = this.entregaEnderecoService.listarEntregaEndereco();
		return ResponseEntity.ok(entregaendereco);
	}
}
