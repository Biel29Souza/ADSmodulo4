//package com.senac.vendas.interfaces;
//
//import java.util.List;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import com.senac.vendas.entities.Vendas;
//
//@Component
//@FeignClient (name="vendas", url="edumysql.acesso.rj.senac.br", path="/vendas")
//public interface VendasFeignClient {
//
//	@GetMapping (value="/")
//	public ResponseEntity<List<Vendas>> listAll();
//}
//
//
