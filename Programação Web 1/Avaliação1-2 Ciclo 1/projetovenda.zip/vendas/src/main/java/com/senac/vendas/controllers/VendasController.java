package com.senac.vendas.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.vendas.entities.Vendas;
import com.senac.vendas.services.VendasService;

@RestController
@RequestMapping(value = "/vendas")

public class VendasController {

	private VendasService vendasService;

	public VendasController(VendasService vendasService) {
		this.vendasService = vendasService;
	}
	
	@GetMapping("/list")	
	public ResponseEntity<List<Vendas>> listarCategoria(){
		List<Vendas> vendas = this.vendasService.obterVendas();
		return ResponseEntity.ok(vendas);
	}
	
	
}



	