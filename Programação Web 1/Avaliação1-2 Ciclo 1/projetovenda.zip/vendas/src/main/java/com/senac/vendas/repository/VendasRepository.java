package com.senac.vendas.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.senac.vendas.entities.Vendas;

@Repository
public interface VendasRepository extends JpaRepository <Vendas, Integer> {

}

