package com.senac.vendas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.vendas.entities.Vendas;
import com.senac.vendas.repository.VendasRepository;

//@Service
//public class VendasService {
//
//	private VendasFeignClient vendasFeignClient;
//	
//	public VendasService(VendasFeignClient vendasFeignClient) {
//		this.vendasFeignClient = vendasFeignClient;
//	}
//	
//	public List<Vendas> obterVendas() {
//		return vendasFeignClient.listAll().getBody();
//	}
//		
//}


@Service
public class VendasService {
	private VendasRepository vendasRepository;
	
	public VendasService(VendasRepository vendasRepository) {
		this.vendasRepository = vendasRepository;
	}
	
	public List<Vendas> listarVendas() {
		return this.vendasRepository.findAll();
	}
	
	public Vendas obterVendas(Vendas vendas) {
		return this.vendasRepository.save(vendas);
	}
}	