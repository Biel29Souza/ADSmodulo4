package com.senac.andersonsales.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.andersonsales.entities.Funcionario;
import com.senac.andersonsales.repository.FuncionarioRepository;


@Service
public class FuncionarioService {
	private FuncionarioRepository funcionarioRepository;
	
	public FuncionarioService(FuncionarioRepository funcionarioRepository) {
		this.funcionarioRepository = funcionarioRepository;
	}


	public List<Funcionario> listarfuncionario(){
		return this.funcionarioRepository.findAll();
	}

	public Funcionario gravarFuncionario(Funcionario funcionario) {
		return this.funcionarioRepository.save(funcionario);
	}
}


