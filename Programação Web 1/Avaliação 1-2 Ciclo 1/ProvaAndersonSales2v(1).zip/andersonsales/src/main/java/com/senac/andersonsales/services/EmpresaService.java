package com.senac.andersonsales.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.andersonsales.entities.Empresa;
import com.senac.andersonsales.interfaces.UserFeignClient;

@Service
public class EmpresaService {
	private UserFeignClient userFeignClient;

	public EmpresaService(UserFeignClient userFeignClient) {
		this.userFeignClient = userFeignClient;
	}
	
	public List<Empresa> obterEmpresas(){
		return userFeignClient.listAll().getBody();
		
	}
	
	
	
	
}