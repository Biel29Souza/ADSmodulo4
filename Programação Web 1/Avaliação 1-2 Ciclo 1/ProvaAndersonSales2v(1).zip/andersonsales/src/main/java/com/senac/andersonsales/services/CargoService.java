package com.senac.andersonsales.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.andersonsales.entities.Cargo;
import com.senac.andersonsales.repository.CargoRepository;

@Service
public class CargoService {
	private CargoRepository cargoRepository;

	public CargoService(CargoRepository cargoRepository) {
		this.cargoRepository = cargoRepository;
	}

	public List<Cargo> listarCargo(){
		return this.cargoRepository.findAll();
	}
	
	public Cargo gravarCargo(Cargo cargo) {
		return this.cargoRepository.save(cargo);
	}

}


