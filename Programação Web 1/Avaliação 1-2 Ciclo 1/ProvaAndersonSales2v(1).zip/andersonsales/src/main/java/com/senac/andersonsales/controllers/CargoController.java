package com.senac.andersonsales.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.andersonsales.entities.Cargo;
import com.senac.andersonsales.services.CargoService;


@RestController
@RequestMapping(value = "/cargo")
public class CargoController {
	private CargoService cargoService;

	public CargoController(CargoService cargoService) {
		this.cargoService = cargoService;
	}
	
	@GetMapping("/list")
	@CrossOrigin(origins="*")
	public ResponseEntity<List<Cargo>> listarCargo(){
		List<Cargo> cargo = this.cargoService.listarCargo();
		return ResponseEntity.ok(cargo);
	}
	
	@PostMapping ("/save")
	public ResponseEntity<Cargo> salvarEstado(@RequestBody Cargo cargo){
		Cargo car = this.cargoService.gravarCargo(cargo);
		return ResponseEntity.ok(car);
	}

}
