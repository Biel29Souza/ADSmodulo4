package com.senac.andersonsales.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.andersonsales.entities.Empresa;
import com.senac.andersonsales.services.EmpresaService;



@RestController
@RequestMapping (value="/empresas")
public class EmpresaController {
	private EmpresaService empresaService;
	
	public EmpresaController(EmpresaService empresaService) {
		this.empresaService = empresaService;
	}
	
	@GetMapping("/list")
	@CrossOrigin(origins = "*")
	public ResponseEntity<List<Empresa>> listarEmpresas(){
		List<Empresa> empresas= this.empresaService.obterEmpresas();
		return ResponseEntity.ok(empresas);
	}

}
