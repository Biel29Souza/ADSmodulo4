package com.senac.andersonsales.interfaces;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import com.senac.andersonsales.entities.Empresa;


@Component
@FeignClient (name="empresa", url="http://10.136.64.229:8080", path="/empresa")
public interface UserFeignClient {
	@GetMapping (value="/list")
	public ResponseEntity<List<Empresa>> listAll();

}
