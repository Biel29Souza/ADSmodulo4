package com.senac.andersonsales.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.andersonsales.entities.Funcionario;
import com.senac.andersonsales.services.FuncionarioService;

@RestController
@RequestMapping(value = "/funcionario")
public class FuncionarioController {
	private FuncionarioService funcionarioService;

	public FuncionarioController(FuncionarioService funcionarioService) {
		this.funcionarioService = funcionarioService;
	}

	@GetMapping("/list")
	public ResponseEntity <List<Funcionario>> listarFuncionario() {
		List<Funcionario> funcionario = this.funcionarioService.listarfuncionario();
		return ResponseEntity.ok(funcionario);
	}

	@PostMapping ("/save")
	public ResponseEntity<Funcionario> salvarFuncionario(@RequestBody Funcionario funcionario){
		Funcionario fun = this.funcionarioService.gravarFuncionario(funcionario);
		return ResponseEntity.ok(fun);
	}
}
