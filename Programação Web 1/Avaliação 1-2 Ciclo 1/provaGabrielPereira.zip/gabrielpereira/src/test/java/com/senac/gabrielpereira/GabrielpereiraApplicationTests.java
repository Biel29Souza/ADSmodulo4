package com.senac.gabrielpereira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GabrielpereiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
