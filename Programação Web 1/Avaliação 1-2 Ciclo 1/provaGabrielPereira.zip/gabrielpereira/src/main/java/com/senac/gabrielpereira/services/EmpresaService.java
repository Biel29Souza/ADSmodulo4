package com.senac.gabrielpereira.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.gabrielpereira.entities.Empresa;
import com.senac.gabrielpereira.repository.EmpresaRepository;

@Service
public class EmpresaService {


	private EmpresaRepository empresaRepository;

	public EmpresaService(EmpresaRepository empresaRepository) {
		this.empresaRepository = empresaRepository;
	}

	public List<Empresa> listarEmpresa() {
		return this.empresaRepository.findAll();
	}
	public Empresa gravarEmpresa(Empresa empresa) {
		return this.empresaRepository.save(empresa);
	}
}





