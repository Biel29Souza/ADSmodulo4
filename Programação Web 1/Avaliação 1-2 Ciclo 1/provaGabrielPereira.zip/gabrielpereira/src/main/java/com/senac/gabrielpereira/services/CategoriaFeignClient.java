package com.senac.gabrielpereira.services;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import com.senac.gabrielpereira.entities.Categoria;

@Component
@FeignClient (name="categoria", url="10.136.64.231:8080", path="/categoria")
public interface CategoriaFeignClient {

	@GetMapping (value="/")
	public ResponseEntity<List<Categoria>> listAll();
}