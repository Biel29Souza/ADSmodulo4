package com.senac.gabrielpereira.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.gabrielpereira.entities.Empresa;

import com.senac.gabrielpereira.services.EmpresaService;




@RestController
@RequestMapping(value = "/empresa")
public class EmpresaController {

	private EmpresaService empresaService;

	public EmpresaController(EmpresaService empresaService) {
		this.empresaService = empresaService;
	}
	
	@GetMapping("/list")
	@CrossOrigin(origins="*")  //Permitir acesso
	public ResponseEntity<List<Empresa>> listarEmpresa(){
		List<Empresa> empresas = this.empresaService.listarEmpresa();
		return ResponseEntity.ok(empresas);
	}

	@PostMapping ("/save")
	public ResponseEntity<Empresa> salvarEmpresa(@RequestBody Empresa empresa){
		Empresa emp = this.empresaService.gravarEmpresa(empresa);
		return ResponseEntity.ok(emp);
	}

	
}



	
	









