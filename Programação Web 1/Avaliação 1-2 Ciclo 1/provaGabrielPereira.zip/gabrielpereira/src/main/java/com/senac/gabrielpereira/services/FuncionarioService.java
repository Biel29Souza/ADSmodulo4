package com.senac.gabrielpereira.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.gabrielpereira.entities.Funcionario;
import com.senac.gabrielpereira.entities.ListaFuncionarios;
import com.senac.gabrielpereira.interfaces.FuncionarioFeignClient;


@Service
public class FuncionarioService {
	private FuncionarioFeignClient funcionarioFeignClient;
	
	public FuncionarioService(FuncionarioFeignClient funcionarioFeignClient) {
		this.funcionarioFeignClient = funcionarioFeignClient;
	}
	
	public List<Funcionario> obterFuncionarios() {
		return funcionarioFeignClient.listAll().getBody();
	}
		
}