//package com.senac.gabrielpereira.interfaces;
//
//import java.util.List;
//
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import com.senac.gabrielpereira.entities.Empresa;
//
//@Component
//@FeignClient (name="empresa", url="10.136.64.231:8080", path="/empresa")
//public interface EmpresaFeignClient {
//
//
//		@GetMapping (value="/")
//		public ResponseEntity<List<Empresa>> listAll();
//}
//	
//
