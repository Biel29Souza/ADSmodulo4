package com.senac.gabrielpereira.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.gabrielpereira.entities.Categoria;
//import com.senac.gabrielpereira.entities.ListaCategoria;
//import com.senac.gabrielpereira.interfaces.UserFeignCategoria;
import com.senac.gabrielpereira.repository.CategoriaRepository;


@Service
public class CategoriaService {
	private CategoriaRepository categoriaRepository;

	public CategoriaService(CategoriaRepository categoriaRepository) {
		this.categoriaRepository = categoriaRepository;
	}

	public List<Categoria> listarCategoria() {
		return this.categoriaRepository.findAll();
	}
	
	public Categoria gravarCategoria(Categoria categoria) {
		return this.categoriaRepository.save(categoria);
	}


}

	






