package com.senac.gabrielpereira.controllers;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.gabrielpereira.entities.Funcionario;
import com.senac.gabrielpereira.entities.ListaFuncionarios;
import com.senac.gabrielpereira.services.FuncionarioService;

@RestController
@RequestMapping(value = "/funcionario")
public class FuncionarioController {

	private FuncionarioService funcionarioService;

	public FuncionarioController(FuncionarioService funcionarioService) {
		this.funcionarioService = funcionarioService;
	}

	@GetMapping("/list")
	@CrossOrigin(origins="*")
	public ResponseEntity <List<Funcionario>> listarFuncionario() {
		List<Funcionario> funcionarios = this.funcionarioService.obterFuncionarios();
		return ResponseEntity.ok(funcionarios);
	}

		
}


//private UserService userService;
//
//public UserController(UserService userService) {
//	this.userService = userService;
//}
//
//@GetMapping("/list")
//public ResponseEntity<ListaUsuarios> listarUsuarios(){
//	ListaUsuarios usuarios = this.userService.obterUsuarios();
//	return ResponseEntity.ok(usuarios);
//}