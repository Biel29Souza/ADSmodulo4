package com.senac.gabrielpereira.interfaces;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import com.senac.gabrielpereira.entities.Funcionario;


@Component
@FeignClient (name="funcionario", url="10.136.64.231:8080", path="/funcionario")
//@FeignClient (name="funcionario", url="http://10.136.64.231:8080", path="/funcionario/list")
public interface FuncionarioFeignClient {

	@GetMapping (value="/")
	public ResponseEntity<List<Funcionario>> listAll();
	
}	