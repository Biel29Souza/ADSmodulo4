package com.senac.GabrielPereira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GabrielPereiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
