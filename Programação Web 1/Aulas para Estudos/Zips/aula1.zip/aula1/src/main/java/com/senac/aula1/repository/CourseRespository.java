package com.senac.aula1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.senac.aula1.entity.Course;

@Repository
public interface CourseRespository extends JpaRepository <Course, Integer> {

}
