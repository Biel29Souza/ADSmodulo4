package com.senac.aula1.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.aula1.entity.Estado;
import com.senac.aula1.repository.EstadoRepository;

@Service
public class EstadoService {
	private EstadoRepository estadoRepository;

	public EstadoService(EstadoRepository estadoRepository) {
		this.estadoRepository = estadoRepository;
	}
	
	public List<Estado> listarEstados(){
		return this.estadoRepository.findAll();		
	}
	
	public Estado gravarEstado(Estado estado) {
		return this.estadoRepository.save(estado);
	}
	
}
