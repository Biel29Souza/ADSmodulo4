package com.senac.aula1.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.aula1.entity.Student;
import com.senac.aula1.service.StudentService;

@RestController
@RequestMapping(value = "/student")
public class StudentController {
	private StudentService studentService;

	public StudentController(StudentService studentService) {
		this.studentService = studentService;
	} 
	
	@GetMapping("/list")
	public ResponseEntity<List<Student>> listarStudent(){
		List<Student> students = this.studentService.listarStudents();
		return ResponseEntity.ok(students);
	}
	
}
