package com.senac.aula1.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.aula1.entity.Estado;
import com.senac.aula1.service.EstadoService;

@RestController
@RequestMapping(value = "/estado")
public class EstadoController {
	private EstadoService estadoService;

	public EstadoController(EstadoService estadoService) {
		this.estadoService = estadoService;
	} 

	@GetMapping("/list")
	public ResponseEntity<List<Estado>> listarEstados(){
		List<Estado> estados = this.estadoService.listarEstados();
		return ResponseEntity.ok(estados);
	}
	
	@PostMapping("/save")
	public ResponseEntity<Estado> salvarEstado(@RequestBody Estado estado){
		Estado est = this.estadoService.gravarEstado(estado);
		return ResponseEntity.ok(est);
	}
	
}
