package com.senac.aula1.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.senac.aula1.entity.UsuarioTipo;
import com.senac.aula1.repository.UsuarioTipoRepository;

@Service
public class UsuarioTipoService {
	private UsuarioTipoRepository usuarioTipoRepository;

	public UsuarioTipoService(UsuarioTipoRepository usuarioTipoRepository) {
		this.usuarioTipoRepository = usuarioTipoRepository;
	}
	
	public List<UsuarioTipo> listarUsuarioTipo(){
		return this.usuarioTipoRepository.findAll();		
	}
}
