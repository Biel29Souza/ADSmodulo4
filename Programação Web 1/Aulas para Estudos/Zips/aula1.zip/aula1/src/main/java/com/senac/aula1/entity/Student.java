package com.senac.aula1.entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;


@Entity
public class Student {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	
	@ManyToMany
	@JoinTable(
	name = "course_like", 
	joinColumns = @JoinColumn(name = "student_id", insertable=false, updatable=false ),
	inverseJoinColumns = @JoinColumn(name = "course_id", insertable=false, updatable=false))
	Set<Course> likedCourses;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public Set<Course> getLikedCourses() {
		return likedCourses;
	}

	public void setLikedCourses(Set<Course> likedCourses) {
		this.likedCourses = likedCourses;
	} 
	
	
}
