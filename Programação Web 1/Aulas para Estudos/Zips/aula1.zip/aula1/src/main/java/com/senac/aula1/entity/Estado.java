package com.senac.aula1.entity;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Estado {
	@Id
	@Column(name="estado_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="estado_nome")
	private String nome;
	
	@Column(name="estado_sigla")
	private String sigla;
		
	@Column(name="estado_status")
	private int status;
	
	@OneToMany(mappedBy="estado")
	private Set<Cidade> cidades;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	public Set<Cidade> getCidades() {
		return cidades;
	}
	public void setCidades(Set<Cidade> cidades) {
		this.cidades = cidades;
	}
	
}
