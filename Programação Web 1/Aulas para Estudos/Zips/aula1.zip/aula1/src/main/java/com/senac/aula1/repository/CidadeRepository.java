package com.senac.aula1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.senac.aula1.entity.Cidade;

public interface CidadeRepository extends JpaRepository <Cidade, Integer>{

}
