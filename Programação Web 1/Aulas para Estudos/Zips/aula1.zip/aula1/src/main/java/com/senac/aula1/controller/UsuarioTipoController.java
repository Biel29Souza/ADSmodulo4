package com.senac.aula1.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.aula1.entity.UsuarioTipo;
import com.senac.aula1.service.UsuarioTipoService;

@RestController
@RequestMapping(value = "/usuariotipo")
public class UsuarioTipoController {
	private UsuarioTipoService usuarioTipoService;

	public UsuarioTipoController(UsuarioTipoService usuarioTipoService) {
		this.usuarioTipoService = usuarioTipoService;
	} 

	@GetMapping("/list")
	public ResponseEntity<List<UsuarioTipo>> listarUsuarioTipo(){
		List<UsuarioTipo> usuariosTipo = this.usuarioTipoService.listarUsuarioTipo();
		return ResponseEntity.ok(usuariosTipo);
	}
}
