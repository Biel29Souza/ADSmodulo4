package com.example.demo.dto;

public record RecoveryJwtTokenDto(String token) {
}
