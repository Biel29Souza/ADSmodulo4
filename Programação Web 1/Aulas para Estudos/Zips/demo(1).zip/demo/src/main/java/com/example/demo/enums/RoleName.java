package com.example.demo.enums;

public enum RoleName {
    ROLE_CUSTOMER,
    ROLE_ADMINISTRATOR
}
