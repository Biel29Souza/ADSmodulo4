package com.example.demo.dto;

public record LoginUserDto(  String email, String password) {
}
