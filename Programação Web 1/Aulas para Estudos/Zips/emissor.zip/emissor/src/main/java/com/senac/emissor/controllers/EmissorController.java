package com.senac.emissor.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.emissor.entities.Emissor;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("Emissor")
@Tag(name = "Emissor", description = "API para comunicação de microserviços")
public class EmissorController {
	
    @GetMapping("/obter")
    @Operation(summary = "Obter um emissor", description = "Endpont para teste de emissor")
    public ResponseEntity<Emissor> obterReceptor() {
    	Emissor emissor = new Emissor();
    	emissor.setId(0);
    	emissor.setNome("Teste de emissor");    	
        return ResponseEntity.ok(emissor);
    }
	
}
