package com.senac.emissor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmissorApplicationTests {

	@Test
	void contextLoads() {
	}

}
