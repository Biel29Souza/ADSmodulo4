package com.senac.receptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceptorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceptorApplication.class, args);
	}

}
