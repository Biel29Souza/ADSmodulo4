package com.senac.receptor.services;

import org.springframework.stereotype.Service;

@Service
public class ReceptorService {

}
