package com.senac.receptor.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.receptor.entities.Receptor;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("Receptor")
@Tag(name = "Receptor", description = "API para comunicação de microserviços")
public class ReceptorController {
	
    @GetMapping("/obter")
    @Operation(summary = "Obter um receptor", description = "Endpont para teste de receptor")
    public ResponseEntity<Receptor> obterReceptor() {
    	Receptor receptor = new Receptor();
    	receptor.setId(0);
    	receptor.setNome("Teste de receptor");    	
        return ResponseEntity.ok(receptor);
    }
	
}
