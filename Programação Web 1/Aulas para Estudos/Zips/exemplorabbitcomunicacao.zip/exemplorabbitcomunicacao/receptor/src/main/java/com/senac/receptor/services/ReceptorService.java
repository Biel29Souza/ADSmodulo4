package com.senac.receptor.services;

import com.senac.receptor.entities.Emissor;
import com.senac.receptor.entities.Resposta;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class ReceptorService {
    @RabbitListener(queues = "fila-johnny")
    public Resposta processarPedido(Emissor emissorEnviado) {

        System.out.println("O emissor recebido: " + emissorEnviado.getNome());

        // Simula algum processamento
        Resposta resposta = new Resposta();

        resposta.setNome("Aprovado "+  emissorEnviado.getNome());
        return resposta;
    }
}
