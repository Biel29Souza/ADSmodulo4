package com.senac.emissor.controllers;


import com.senac.receptor.entities.Resposta;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.emissor.entities.Emissor;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.Map;

@RestController
@RequestMapping("Emissor")
@Tag(name = "Emissor", description = "API para comunicação de microserviços")
public class EmissorController {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @GetMapping("/enviarobjetonafila")
    @Operation(summary = "Enviar um objeto emissor na fila", description = "Endpont para colocação de um objeto emissor na fila do rabbitmq")
    public ResponseEntity<Emissor> enviarEmissor() {
    	Emissor emissor = new Emissor();
    	emissor.setId(0);
    	emissor.setNome("Teste de emissor");
        rabbitTemplate.convertAndSend("fila-johnny", emissor);
        return ResponseEntity.ok(emissor);
    }

    @GetMapping("/enviarereceberarobjetonafila")
    @Operation(summary = "Enviar um objeto emissor na fila", description = "Endpont para colocação de um objeto emissor na fila do rabbitmq")
    public ResponseEntity<Resposta> enviarereceberEmissor() {
        Emissor emissor = new Emissor();
        emissor.setId(0);
        emissor.setNome("Emissor Johnny");
        Object resposta = rabbitTemplate.convertSendAndReceive("fila-johnny", emissor);

        return ResponseEntity.ok((Resposta) resposta);
    }

	
}
