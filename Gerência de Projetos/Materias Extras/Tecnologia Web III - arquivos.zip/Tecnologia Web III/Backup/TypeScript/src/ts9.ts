class Pessoa {
    constructor (nome:string, idade:number) {
        this.nome = nome;
        this.idade = idade;
    }
    public nome : string;
	public idade : number;
    public alistar () : void {
        if (this.idade>=18)
            this.imprimir(`${this.nome} você tem que se alistar`);
        else
            this.imprimir(`${this.nome} você não pode se alistar`);
	}
    private imprimir (mensagem : string) : void {
        console.log(mensagem);
    }
}
class Homem extends Pessoa {}
class Mulher extends Pessoa {
    alistar () : void { // Sobrescrita de método
        if (this.idade>=18)
            console.log(`${this.nome} você pode se alistar`);
        else
            console.log(`${this.nome} você ainda não pode se alistar`);
	}
}
const homem1 = new Homem("Carlos", 25);
homem1.alistar();
const homem2 = new Homem("João", 15);
homem2.alistar();
const mulher1 = new Mulher("Maria", 25);
mulher1.alistar();
const mulher2 = new Mulher("Juliana", 15);
mulher2.alistar();
// mulher2.imprimir("teste"); // Esta linha não funciona porque o método imprimir é privado