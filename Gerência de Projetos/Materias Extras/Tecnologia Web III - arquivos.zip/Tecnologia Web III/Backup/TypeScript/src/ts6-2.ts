enum genero {
    Masculino = 1,
    Feminino = 2
}
let valor : number = 1;
if (valor == genero.Masculino)
    console.log("O gênero é Masculino");
else
    console.log("O gênero é Feminino");