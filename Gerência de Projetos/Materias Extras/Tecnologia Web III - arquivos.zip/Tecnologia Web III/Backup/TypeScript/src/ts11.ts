interface Pessoa {
	nome : string;
	idade : number;
    alistar() : void; // apenas a assinatura do método
}
class Pessoa implements Pessoa{
    constructor (nome:string, idade:number) {
        this.nome = nome;
        this.idade = idade;
    }
    public nome : string;
	public idade : number;
    public alistar () : void {
        if (this.idade>=18)
            this.imprimir(`${this.nome} você tem que se alistar`);
        else
            this.imprimir(`${this.nome} você não pode se alistar`);
	}
    private imprimir (mensagem : string) : void {
        console.log(mensagem);
    }
}
export class Homem extends Pessoa {}
export class Mulher extends Pessoa {
    alistar () : void { // Sobrescrita do método
        if (this.idade>=18)
            console.log(`${this.nome} você pode se alistar`);
        else
            console.log(`${this.nome} você ainda não pode se alistar`);
	}
}
// export { Homem, Mulher }; // O export das classes poderia ficar aqui