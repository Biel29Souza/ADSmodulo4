type fruta = {
    cor : string;
    preco : number;
}
let banana : fruta;
banana = {
    cor : "Amarela",
    preco : 10
}
//console.log(banana.validade); // Não funciona porque o objeto não possui a propriedade validade
console.log(banana.cor); // Amarela
let melancia : fruta;
melancia = {
    cor : "Vermelha",
    preco : 15,
    // qtde : 30 // o tipo atributo não possui a propriedade qtde
}
type veiculo = {
    readonly fabricante : string;
    modelo : string;
    ano? : number; // ano não é obrigatório
}
let carro : veiculo;
carro = {
    fabricante : "Fiat",
    modelo : "Palio"
}
//gol.fabricante = "Fiat"; // a propriedade fabricante não pode ser sobrescrita
carro.modelo = "Ka";
console.log(carro); // { fabricante: 'Fiat', modelo: 'Ka' }
type veiculoFruta = veiculo & fruta;
let carroFruta : veiculoFruta; 
carroFruta = {
    fabricante : "Chevrolet",
    modelo : "Chevette",
    cor : "Azul",
    preco : 15
}
console.log(carroFruta); // { fabricante: 'Chevrolet', modelo: 'Chevette', cor: 'Azul', preco: 15 }