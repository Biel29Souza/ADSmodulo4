interface Pessoa {
	nome : string;
	idade : number;
    alistar() : void; // apenas a assinatura do método
}
class Homem implements Pessoa {  // Classe Homem implementa a interface Pessoa
    constructor (nome:string, idade:number) {
        this.nome = nome;
        this.idade = idade;
    }
    nome : string;
	idade : number;
    alistar () : void {
        if (this.idade>=18)
            console.log(`${this.nome} você tem que se alistar`);
        else
            console.log(`${this.nome} você não pode se alistar`);
	}
}
const homem1 = new Homem("Carlos", 25);
homem1.alistar();
const homem2 = new Homem("João", 15);
homem2.alistar();