import { Homem, Mulher } from "./ts11.js";
const homem1 = new Homem("Paulo", 25);
homem1.alistar();
const mulher1 = new Mulher("Beatriz", 25);
mulher1.alistar();