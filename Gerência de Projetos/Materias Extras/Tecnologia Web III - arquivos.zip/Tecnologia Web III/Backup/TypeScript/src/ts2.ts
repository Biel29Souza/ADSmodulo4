let mensagem : string = "Bem-vindo!!!";
console.log(mensagem);