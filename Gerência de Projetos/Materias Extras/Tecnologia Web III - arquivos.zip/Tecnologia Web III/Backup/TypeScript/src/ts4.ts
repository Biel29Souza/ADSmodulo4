let nome : string;
nome = "Carlos";