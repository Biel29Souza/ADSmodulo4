function decoradorClasse(construtor : Function) {
    console.log("decoradorClasse");
    console.log("construtor: " + construtor);
}
function decoradorPropriedade(prototipo : any, nomePropriedade : string) {
    console.log("decoradorPropriedade");
    console.log("prototipo: " + prototipo);
    console.log("nomePropriedade: " + nomePropriedade);
}
function decoradorMetodo(prototipo : any, nomeMetodo : string, descritorPropriedade : PropertyDescriptor) {
    console.log("decoradorMetodo");
    console.log("prototipo: " + prototipo);
    console.log("nomeMetodo: " + nomeMetodo);
    console.log("descritorPropriedade: " + descritorPropriedade);
}
interface Pessoa {
	nome : string;
	idade : number;
    alistar() : void; // apenas a assinatura do método
}
@decoradorClasse
class Homem implements Pessoa {  // Classe Homem implementa a interface Pessoa
    constructor (nome:string, idade:number) {
        this.nome = nome;
        this.idade = idade;
    }
    @decoradorPropriedade nome : string;
	idade : number;
    @decoradorMetodo alistar () : void {
        if (this.idade>=18)
            console.log(`${this.nome} você tem que se alistar`);
        else
            console.log(`${this.nome} você não pode se alistar`);
	}
}
const homem1 = new Homem("Carlos", 25);
homem1.alistar();
const homem2 = new Homem("João", 15);
homem2.alistar();
