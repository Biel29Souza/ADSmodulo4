function calcularTamanho(codigo: number | string) {
    if (typeof codigo == 'string')
        console.log(codigo.length);
    else
        console.log(codigo.toString().length);
}
calcularTamanho(12345);
calcularTamanho("12345");