let resultado : undefined | number;
console.log(typeof resultado);
resultado = 10/2;
console.log(typeof resultado);