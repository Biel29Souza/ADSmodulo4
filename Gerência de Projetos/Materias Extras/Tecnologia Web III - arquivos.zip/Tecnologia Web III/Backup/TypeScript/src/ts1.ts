let mensagem : string = "Olá Mundo!!! Estou aqui.";
console.log(mensagem);
export {};