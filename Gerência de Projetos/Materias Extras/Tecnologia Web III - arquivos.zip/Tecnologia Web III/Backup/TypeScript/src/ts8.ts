function soma (a : number, b : number) : number { // parâmetros e retorno com tipos declarados
    return (a + b);
}
let total1 = soma(10, 5);
console.log("total1 = " + total1); // total1 = 15
//let total11 = soma(10); // Não funciona pela falta de um dos parâmetros
function soma2 (a : number, b? : number) { // b pode ser number ou undefined se não receber valor
    if (b == undefined)
        return a;
    else
        return (a + b);
}
let total2 = soma2(10); // total2 será inferido como tipo number mesmo sem o tipo do retorno
console.log("total2 = " + total2); // total2 = 10
let total3 = soma2(10, 20); // total3 será inferido como tipo number mesmo sem o tipo do retorno
console.log("total3 = " + total3); // total3 = 30
function soma3 (a : number, b : number) : void { // void indica função sem retorno
    console.log("soma = " + (a + b)); // soma = 15
    return;
}
soma3(10, 5);
// T indica Tipo, mas poderia ser outra letra ou palavra no lugar como Tipo
function generica<T> (a : T) : T { // função genérica - parâmetro a poderá ser de qualquer tipo
    return a;
}
let valor1 = generica(1);
console.log("valor1 = " + valor1); // valor1 = 1
let valor2 = generica("carlos");
console.log("valor2 = " + valor2); // valor2 = carlos
function soma4 (a : number, ...b : number[ ]) : number { // b será um array de números
    let total = a;
    for (let numero of b) { // iteração no array b
        total += numero;
    }
    return total;
}
let valor3 = soma4(2, 4, 3, 5); // valores 4, 3 e 5 farão parte do array b
console.log("valor3 = " + valor3); // valor3 = 14