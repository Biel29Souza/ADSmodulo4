function exibirNome(nome : string) {
    console.log(nome);
}
exibirNome("João");
