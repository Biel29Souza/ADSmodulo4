import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrincipalComponent } from './componentes/principal/principal.component';

@Component({
  selector: 'app-root',
  imports: [CommonModule, PrincipalComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Projeto1';
  // responsavel = 'Zezinho';
  // listaEquipe = ['João', 'Maria', 'Luciana'];
  // cor = '#0000ff';
  // tamanhoFonte = 20;
  // classe = 'corFundo';
  // exibirComponenteEventos = true;
}
