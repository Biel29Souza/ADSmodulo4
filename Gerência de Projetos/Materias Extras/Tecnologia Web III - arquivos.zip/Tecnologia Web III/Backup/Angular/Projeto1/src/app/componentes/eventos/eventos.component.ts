import { AfterViewInit, Component, DoCheck, ElementRef, OnChanges, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { CaixaDialogoSimplesComponent } from '../dialogos/caixa-dialogo-simples/caixa-dialogo-simples.component';
import { CaixaDialogoConfirmacaoComponent } from '../dialogos/caixa-dialogo-confirmacao/caixa-dialogo-confirmacao.component';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-eventos',
  imports: [MatDialogModule, CaixaDialogoSimplesComponent, CaixaDialogoConfirmacaoComponent],
  templateUrl: './eventos.component.html',
  styleUrl: './eventos.component.css'
})
export class EventosComponent implements OnChanges, OnInit, DoCheck, AfterViewInit, OnDestroy {
  constructor(private dialog: MatDialog) { }
  @ViewChild('email') email!: ElementRef;
  @ViewChild('senha') senha!: ElementRef;

  async verificarDados() {
    if (await this.abrirConfirmacao('Atenção', 'Deseja realmente entrar?')) {
      if (this.email.nativeElement.value=="") {
        alert("Preencha o e-mail.");
        this.email.nativeElement.focus();
      } else if (this.senha.nativeElement.value=="") {
        alert("Preencha a senha");
        this.senha.nativeElement.focus();
      } else
        alert("Dados preenchidos corretamente");
    } 
  }
  abrirConfirmacao(tituloDialogo : string, conteudoDialogo : string) : Promise<boolean> {
    let resultado : boolean = false;
    const caixaConfirmacao = this.dialog.open(CaixaDialogoConfirmacaoComponent, {
      width: '200px',
      height: '200px',
      data: {
        titulo: tituloDialogo,
        conteudo: conteudoDialogo
      },
    });
    return lastValueFrom(caixaConfirmacao.afterClosed());
  }
  exibirMensagem(campo : string) {
    alert("Campo modificado: "+campo);
  }
  abrirDialogo(tituloDialogo : string, conteudoDialogo : string) {
    const caixaDialogo = this.dialog.open(CaixaDialogoSimplesComponent, {
      width: '200px',
      height: '200px',
      data: {
        titulo: tituloDialogo,
        conteudo: conteudoDialogo
      },
    });
  }
  ngAfterViewInit() {
    this.abrirDialogo('Bem-vindo', 'Este é o evento ngAfterViewInit');
    this.email.nativeElement.focus();
  }
  ngOnDestroy() {
    this.abrirDialogo('Bem-vindo', 'Este é o evento ngOnDestroy');
  }
  ngDoCheck() {
    //alert("ngDoCheck");
  }
  ngOnChanges() {
    //alert("ngOnChanges");
  }
  ngOnInit() {
    //alert('ngOnInit');
  }
}
