import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-exemplo',
  imports: [],
  templateUrl: './exemplo.component.html',
  styleUrl: './exemplo.component.css'
})
export class ExemploComponent {
  @Input () responsavelProjeto = '';
  idade = 10;
  op = 9;
}
